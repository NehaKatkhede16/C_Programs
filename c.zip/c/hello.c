#include<stdio.h>
int main(){

printf("LOVE YOU DEAR❤️");
    return 0;
}


