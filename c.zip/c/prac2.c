//#To study and execute the Linear search method.
#include <stdio.h>
void main()
{
int search,i;
int array[10]={25,6,2,48,0,4,26,19,33,51};
printf("Enter the number to search\n");
scanf("%d", &search);
for (i = 0; i<10; i++)
{
if (array[i] == search)
{
printf("%d is present at location %d \n", search, i+1);
break;
}

}
if (i == 10)
printf("%d is not present in array.\n", search);
}