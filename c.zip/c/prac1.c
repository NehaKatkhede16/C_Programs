//Write a program to perform following operations on array.
//i. Find out largest number and find it’s location.
//ii. a) Insert an element in an array b)delete an element from an array.
//iii. Traverse an array and find the sum and average of data elements from an array.
#include<stdio.h>
#include<stdlib.h>
int a[20];
int m,n,p,val,i,pos,temp,sum,avg;
/*Function Prototype*/
void create();
void insert();
void del();
void search();
void total();
int main()
{
int choice;
do{
printf("\n\n--------Menu-----------\n");
printf("1.Create\n");
printf("2.Insert\n");
printf("3.Delete\n");
printf("4.Search\n");
printf("5.Total\n");
printf("6.Exit\n");
printf("-----------------------");
printf("\nEnter your choice:\t");
scanf("%d",&choice);
switch(choice)
{
case 1: create();
break;
case 2:
insert();

break;
case 3:
del();
break;
case 4:
search();
break;
case 5:
total();
break;
case 6:
exit(0);
break;
default:
printf("\nInvalid choice:\n");
break;
}
}while(choice!=6);
return 0;
}
void create() //creating an array
{
printf("\nEnter the size of the array elements:\t");
scanf("%d",&n);
printf("\nEnter the elements for the array:\n");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("\nThe array elements are:\n");
for(i=0;i<n;i++){
printf("%d\t",a[i]);
}
}
void insert()
{
printf("\nEnter the position for the new element:\t");
scanf("%d",&pos);
printf("\nEnter the element to be inserted :\t");

scanf("%d",&val);
for(i=n-1;i>=pos;i--)
{
a[i+1]=a[i];
}
a[pos]=val;
n=n+1;
printf("\n Afte inserting element the array elements are:\n");
for(i=0;i<n;i++){
printf("%d\t",a[i]);
}
}
void del()
{
printf("\nEnter the position of the element to be deleted:\t");
scanf("%d",&pos);
val=a[pos];
for(i=pos;i<n-1;i++)
{
a[i]=a[i+1];
}
n=n-1;
printf("\nThe deleted element is =%d",val);
}
void search()
{
temp = a[0];
for (i = 0; i < n; i++)
if (a[i] > temp)
temp = a[i];
printf("\n The largest element in the array is =%d present at position %d ",temp,i);

}
void total()
{
printf("\n Sum of elements in array :");
for (i = 0; i < n; i++)

sum = sum + a[i];
printf("%d", sum);
avg = sum/n+1;
printf("\n Average of elements is :%d",avg);
}